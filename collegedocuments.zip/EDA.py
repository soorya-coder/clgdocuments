# Import required library
import pandas as pd


# --------------------------------------------------
# 1. CREATE A SAMPLE DATASET
# --------------------------------------------------

data = {
    "Name": [
        "Arun", "Bala", "Charan", "Divya", "Esha",
        "Farah", "Gokul", "Hari", "Indhu", "Jaya"
    ],

    "Age": [
        20, 21, 22, 20, 21,
        23, 22, 20, 21, 22
    ],

    "Department": [
        "CSE", "IT", "CSE", "ECE", "CSE",
        "IT", "ECE", "CSE", "IT", "ECE"
    ],

    "Marks": [
        85, 72, 91, 65, 88,
        76, 80, 95, 70, 82
    ],

    "Attendance": [
        90, 75, 95, 70, 88,
        80, 85, 98, 72, 89
    ]
}


# --------------------------------------------------
# 2. CREATE DATAFRAME
# --------------------------------------------------

df = pd.DataFrame(data)

print("ORIGINAL DATASET")
print(df)


# --------------------------------------------------
# 3. BASIC DATA INSPECTION
# --------------------------------------------------

print("\nFIRST 5 ROWS")
print(df.head())

print("\nLAST 5 ROWS")
print(df.tail())

print("\nSHAPE OF DATASET")
print(df.shape)

print("\nCOLUMN NAMES")
print(df.columns)

print("\nDATA TYPES")
print(df.dtypes)

print("\nDATASET INFORMATION")
df.info()


# --------------------------------------------------
# 4. CHECK FOR MISSING VALUES
# --------------------------------------------------

print("\nMISSING VALUES IN EACH COLUMN")
print(df.isnull().sum())


# --------------------------------------------------
# 5. DESCRIPTIVE STATISTICS
# --------------------------------------------------

print("\nSTATISTICAL SUMMARY")
print(df.describe())


# --------------------------------------------------
# 6. INDIVIDUAL STATISTICAL MEASURES
# --------------------------------------------------

print("\nMEAN OF MARKS")
print(df["Marks"].mean())

print("\nMEDIAN OF MARKS")
print(df["Marks"].median())

print("\nMODE OF MARKS")
print(df["Marks"].mode())

print("\nMAXIMUM MARKS")
print(df["Marks"].max())

print("\nMINIMUM MARKS")
print(df["Marks"].min())

print("\nSTANDARD DEVIATION OF MARKS")
print(df["Marks"].std())

print("\nVARIANCE OF MARKS")
print(df["Marks"].var())


# --------------------------------------------------
# 7. FREQUENCY ANALYSIS
# --------------------------------------------------

print("\nNUMBER OF STUDENTS IN EACH DEPARTMENT")
print(df["Department"].value_counts())


# --------------------------------------------------
# 8. GROUP-WISE ANALYSIS
# --------------------------------------------------

print("\nAVERAGE MARKS BY DEPARTMENT")

average_marks = df.groupby(
    "Department"
)["Marks"].mean()

print(average_marks)


# --------------------------------------------------
# 9. CORRELATION
# --------------------------------------------------

print("\nCORRELATION MATRIX")

numeric_data = df[
    ["Age", "Marks", "Attendance"]
]

correlation = numeric_data.corr()

print(correlation)


# --------------------------------------------------
# 10. COVARIANCE
# --------------------------------------------------

print("\nCOVARIANCE MATRIX")

covariance = numeric_data.cov()

print(covariance)